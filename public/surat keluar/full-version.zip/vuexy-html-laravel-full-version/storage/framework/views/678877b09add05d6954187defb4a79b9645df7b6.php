<?php $__env->startSection('title', 'Media Player'); ?>

<?php $__env->startSection('vendor-style'); ?>
        <!-- vendor css files -->
        <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/plyr.css'))); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-style'); ?>
        <!-- Page css files -->
        <link rel="stylesheet" href="<?php echo e(asset(mix('css/plugins/extensions/media-plyr.css'))); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <!-- Media Player Start here -->
<section id="media-player-wrapper">
  <div class="row">
    <div class="col-md-12">
      <div class="card p-2">
        <h6 class="card-title">Video</h6>
        <!-- VIDEO -->
        <div class="video-player" id="plyr-video-player">
          <iframe
            src="https://www.youtube.com/embed/bTqVqk7FSmY?origin=https://plyr.io&amp;iv_load_policy=3&amp;modestbranding=1&amp;playsinline=1&amp;showinfo=0&amp;rel=0&amp;enablejsapi=1"
            allowfullscreen allow="autoplay">
          </iframe>
        </div>
        <!-- VIDEO END -->
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-md-12">
      <div class="card p-2">
        <!-- AUDIO -->
        <h6 class="card-title">Audio</h6>
        <audio id="plyr-audio-player" class="audio-player" controls>
          <source src="https://cdn.plyr.io/static/demo/Kishi_Bashi_-_It_All_Began_With_a_Burst.mp3" type="audio/mp3" />
          <source src="https://cdn.plyr.io/static/demo/Kishi_Bashi_-_It_All_Began_With_a_Burst.ogg" type="audio/ogg" />
        </audio>
        <!-- AUDIO END -->
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
        <!-- vendor files -->
        <script src="<?php echo e(asset(mix('vendors/js/media/plyr.js'))); ?>"></script>
        <script src="<?php echo e(asset(mix('vendors/js/media/plyr.polyfilled.js'))); ?>"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
        <!-- Page js files -->
        <script src="<?php echo e(asset(mix('js/scripts/extensions/media-plyr.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vuexy-admin/vuexy-html-laravel-template/resources/views//pages/ext-component-plyr.blade.php ENDPATH**/ ?>