<?php $__env->startSection('title', 'Tour'); ?>

<?php $__env->startSection('vendor-style'); ?>
  <!-- vendor css files -->
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/tether-theme-arrows.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/tether.min.css'))); ?>">
  <link rel="stylesheet" href="<?php echo e(asset(mix('vendors/css/extensions/shepherd.min.css'))); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-style'); ?>
  <!-- Page css files -->
  <link rel="stylesheet" href="<?php echo e(asset(mix('css/base/plugins/extensions/ext-component-tour.css'))); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Basic tour -->
<section id="basic-tour">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Tour</h4>
        </div>
        <div class="card-body">
          <div class="btn btn-outline-primary" id="tour">Start Tour</div>
        </div>
      </div>
    </div>
  </div>
</section>
<!--/ Basic tour -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
  <!-- vendor files -->
  <script src="<?php echo e(asset(mix('vendors/js/extensions/tether.min.js'))); ?>"></script>
  <script src="<?php echo e(asset(mix('vendors/js/extensions/shepherd.min.js'))); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-script'); ?>
  <!-- Page js files -->
  <script src="<?php echo e(asset(mix('js/scripts/extensions/ext-component-tour.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vuexy-admin/vuexy-html-laravel-template/resources/views//content/extensions/ext-component-tour.blade.php ENDPATH**/ ?>