<?php $__env->startSection('title', 'Clipboard'); ?>

<?php $__env->startSection('content'); ?>
<!-- Copy to clipboard Starts -->
<Section id="copy-to-clipboard">
  <div class="row">
    <div class="col-sm-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title">Clipboard</h4>
        </div>
        <div class="card-content">
          <div class="card-body">
            <div class="row">
              <div class="col-md-2 col-sm-12 pr-0">
                <div class="form-group">
                  <input type="text" class="form-control" id="copy-to-clipboard-input" value="Copy Me!">
                </div>
              </div>
              <div class="col-md-2 col-sm-12">
                <button class="btn btn-primary" id="btn-copy">Copy!</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</Section>
<!-- Copy to clipboard Starts -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
        <!-- Page js files -->
        <script src="<?php echo e(asset(mix('js/scripts/extensions/copy-to-clipboard.js'))); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentLayoutMaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/vuexy-admin/vuexy-html-laravel-template/resources/views//pages/ext-component-clipboard.blade.php ENDPATH**/ ?>